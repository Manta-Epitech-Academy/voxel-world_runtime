-- Étape 2 : le sol plat
-- Deux boucles imbriquées parcourent les 128 × 128 colonnes du monde.

for x = 0, TAILLE - 1 do
  for z = 0, TAILLE - 1 do
    bloc(x, 0, z, HERBE)
  end
end
