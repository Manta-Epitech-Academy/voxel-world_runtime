-- Étape 7 : forêts, grottes et minerais
-- Le générateur complet.

NIVEAU_MER = 22
NIVEAU_NEIGE = 34

-- Un bloc de pierre, qui devient parfois un minerai.
function pierre(y)
  local r = hasard(1, 200)
  if y < 12 and r == 1 then
    return DIAMANT
  elseif r <= 4 then
    return CHARBON
  elseif r <= 6 then
    return FER
  end
  return PIERRE
end

-- Vrai si la case (x, y, z) est creusée par une grotte.
function grotte(x, y, z)
  return bruit3d(x / 16, y / 10, z / 16) > 0.3
end

function colonne(x, z, h)
  local dessus, sous = HERBE, TERRE
  if h <= NIVEAU_MER + 1 then
    dessus, sous = SABLE, SABLE
  elseif h >= NIVEAU_NEIGE then
    dessus = NEIGE
  end

  bloc(x, 0, z, SOCLE)
  for y = 1, h - 4 do
    -- Les grottes restent sous la surface : elles ne crèvent pas le sol.
    if not (y < h - 5 and grotte(x, y, z)) then
      bloc(x, y, z, pierre(y))
    end
  end
  for y = h - 3, h - 1 do
    bloc(x, y, z, sous)
  end
  bloc(x, h, z, dessus)

  for y = h + 1, NIVEAU_MER do
    bloc(x, y, z, EAU)
  end
end

function hauteur(x, z)
  local n = bruit(x / 60, z / 60) * 24
          + bruit(x / 24, z / 24) * 6
          + bruit(x / 8, z / 8) * 1.5
  return math.floor(26 + n)
end

-- y est la case juste au-dessus de l'herbe.
function arbre(x, y, z)
  for i = 0, 4 do
    bloc(x, y + i, z, BOIS)
  end
  for dx = -2, 2 do
    for dz = -2, 2 do
      for dy = 3, 4 do
        if not (dx == 0 and dz == 0) then
          bloc(x + dx, y + dy, z + dz, FEUILLES)
        end
      end
    end
  end
  for dx = -1, 1 do
    for dz = -1, 1 do
      bloc(x + dx, y + 5, z + dz, FEUILLES)
    end
  end
end

for x = 0, TAILLE - 1 do
  for z = 0, TAILLE - 1 do
    colonne(x, z, hauteur(x, z))
  end
end

-- On tente 80 arbres ; seuls ceux qui tombent sur de l'herbe poussent.
for i = 1, 80 do
  local x = hasard(2, TAILLE - 3)
  local z = hasard(2, TAILLE - 3)
  local y = HAUTEUR - 1
  while y > 0 and lire(x, y, z) == AIR do
    y = y - 1
  end
  if lire(x, y, z) == HERBE then
    arbre(x, y + 1, z)
  end
end
