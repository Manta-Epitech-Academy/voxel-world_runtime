-- Étape 1 : mon premier bloc
-- bloc(x, y, z, type) pose un bloc. y est la hauteur.

bloc(64, 10, 64, PIERRE)
