-- Étape 5 : le vrai relief
-- Le bruit de Perlin donne des collines qui ne se répètent jamais.
-- Trois « octaves » : de grandes collines, des bosses moyennes, des petits détails.

function colonne(x, z, h)
  bloc(x, 0, z, SOCLE)
  for y = 1, h - 4 do
    bloc(x, y, z, PIERRE)
  end
  for y = h - 3, h - 1 do
    bloc(x, y, z, TERRE)
  end
  bloc(x, h, z, HERBE)
end

function hauteur(x, z)
  local n = bruit(x / 60, z / 60) * 24
          + bruit(x / 24, z / 24) * 6
          + bruit(x / 8, z / 8) * 1.5
  return math.floor(26 + n)
end

for x = 0, TAILLE - 1 do
  for z = 0, TAILLE - 1 do
    colonne(x, z, hauteur(x, z))
  end
end
