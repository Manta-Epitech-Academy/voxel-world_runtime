-- Étape 4 : les collines
-- Chaque colonne a maintenant sa propre hauteur, calculée avec math.sin.

function colonne(x, z, h)
  bloc(x, 0, z, SOCLE)
  for y = 1, h - 4 do
    bloc(x, y, z, PIERRE)
  end
  for y = h - 3, h - 1 do
    bloc(x, y, z, TERRE)
  end
  bloc(x, h, z, HERBE)
end

for x = 0, TAILLE - 1 do
  for z = 0, TAILLE - 1 do
    local h = 20 + math.floor(4 * math.sin(x / 8) + 4 * math.sin(z / 11))
    colonne(x, z, h)
  end
end
