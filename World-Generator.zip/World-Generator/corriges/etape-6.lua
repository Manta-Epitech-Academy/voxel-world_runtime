-- Étape 6 : mers, plages et neige
-- Le bloc du dessus dépend de l'altitude : sable près de l'eau, neige en haut.

NIVEAU_MER = 22
NIVEAU_NEIGE = 34

function colonne(x, z, h)
  local dessus, sous = HERBE, TERRE
  if h <= NIVEAU_MER + 1 then
    dessus, sous = SABLE, SABLE
  elseif h >= NIVEAU_NEIGE then
    dessus = NEIGE
  end

  bloc(x, 0, z, SOCLE)
  for y = 1, h - 4 do
    bloc(x, y, z, PIERRE)
  end
  for y = h - 3, h - 1 do
    bloc(x, y, z, sous)
  end
  bloc(x, h, z, dessus)

  -- L'eau remplit tout ce qui est sous le niveau de la mer.
  for y = h + 1, NIVEAU_MER do
    bloc(x, y, z, EAU)
  end
end

function hauteur(x, z)
  local n = bruit(x / 60, z / 60) * 24
          + bruit(x / 24, z / 24) * 6
          + bruit(x / 8, z / 8) * 1.5
  return math.floor(26 + n)
end

for x = 0, TAILLE - 1 do
  for z = 0, TAILLE - 1 do
    colonne(x, z, hauteur(x, z))
  end
end
