-- Étape 3 : les couches
-- Du bas vers le haut : socle, pierre, 3 blocs de terre, herbe.

local SOL = 20

for x = 0, TAILLE - 1 do
  for z = 0, TAILLE - 1 do
    bloc(x, 0, z, SOCLE)
    for y = 1, SOL - 4 do
      bloc(x, y, z, PIERRE)
    end
    for y = SOL - 3, SOL - 1 do
      bloc(x, y, z, TERRE)
    end
    bloc(x, SOL, z, HERBE)
  end
end
